export default function ContactUs(){
    return(<h1>Contact Us</h1>)
}